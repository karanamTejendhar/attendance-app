
/*

*   AUTHOR : H.O Sai Varshith
*   ROLL : 17CS30015
*   DATE : 03-04-2019

* This Class Reads the course_id, prof name and students list from the supplies
* csv file and creates a new course table and adds the course_ids to the users
* table.
* 
* The First line of the file should contain course_id, prof_username The next
* lines contain a list of student roll nos in the format roll_no, name.

* The JDBC Connector file used is in the same directory. Use it !

* THE STUDENT LIST FILE MUST BE IN CSV FORMAT !!!

*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.*;

public class addCourse {

    public static void main(String args[]) {
        // The only arguement required by the program is the name of the course file.
        if (args.length < 1 || args.length > 2) {
            System.out.println("Invalid Arguements !!!");
            System.exit(-1);
        }
        String student_list = args[0];
        String file_ext = student_list.replaceAll("^.*\\.(.*)$", "$1");
        if (!student_list.replaceAll("^.*\\.(.*)$", "$1").equals("csv")) {
            System.out.println("The file is not in CSV Format. Try Again !!!");
            System.exit(-1);
        }

        String course_id, prof_username, current_line, current_roll, current_name;
        String table_name, temptable_name;
        BufferedReader bf_reader = null;
        String[] current_pairs = null;

        // JDBC Parameters
        String JDBC_DRIVER = "com.mysql.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost/proxynt";
        String USER = "devel_user";
        String PASS = "devel_Password2000*";
        String create_table_query, insert_student_query, insert_course_query, select_student_query;
        Connection db_connection = null;
        Statement stmt = null;
        try {
            bf_reader = new BufferedReader(new FileReader(student_list));
            // By now we have obtained the input file, we need to get the course_id,
            // prof_username;
            current_line = bf_reader.readLine();
            current_pairs = current_line.split(",", 2);
            course_id = current_pairs[0];
            prof_username = current_pairs[1].trim();
            table_name = course_id + "$" + prof_username;

            // Initiate JDBC Connection
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("Connecting to database...");
            db_connection = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connection Successful !");
            stmt = db_connection.createStatement();
            /*
             * Create a new course table whose name is course_id and it contains the columns
             * (roll, attendance_status)
             */
            String create_temp_table = "CREATE TABLE IF NOT EXISTS " + "temp_"+ course_id
                    + " (roll VARCHAR(255) NOT NULL, attendance_status VARCHAR(255) DEFAULT 'a',imei  VARCHAR(255), ipadd VARCHAR(255), UNIQUE(roll), UNIQUE(imei)); ";
            System.out.println("Creating temp Course Table ...");
            stmt.executeUpdate(create_temp_table);
            System.out.println("Succefully Created temp Course Table");                              
            create_table_query = "CREATE TABLE IF NOT EXISTS " + course_id
                    + " (roll VARCHAR(255) NOT NULL, attendance TEXT, UNIQUE(roll)); ";
            System.out.println("Creating Course Table ...");
            stmt.executeUpdate(create_table_query);
            System.out.println("Succefully Created Course Table");

            /*
             * Now we need to read through the list and adds each student to the course
             * table and adds this course to each student in the user table
             */
            // System.out.println("Prof : " + prof_username);
            // System.out.println("C_id : " + course_id);

            // Add the course to courseID table
            String insert_into_classStatus = "INSERT INTO classStatus VALUES('" + course_id + "', 'n', 'n');";
            stmt.executeUpdate(insert_into_classStatus);
            System.out.println("Inserted " + course_id + " into classStatus Table !");
            // Add the courses to prof courses list

            select_student_query = "SELECT courses from users WHERE username = " + "'" + prof_username + "';";
            ResultSet rs = stmt.executeQuery(select_student_query);
            if (!(rs.next() == false)) {
                String current_course_list = rs.getString("courses");
                String final_course_list = createFinalCourseString(current_course_list, course_id, true);
                insert_course_query = "UPDATE users SET courses = " + "'" + final_course_list + "' WHERE username = "
                        + "'" + prof_username + "';";
                stmt.executeUpdate(insert_course_query);
            } else {
                System.out.println("Error in inserting courses into users table for " + prof_username + " !");
            }

            System.out.println("Inserting Students into the Course Table ... ");
            int count = 0;
            String temp_table_attendance ;
            while (true) {
                current_line = bf_reader.readLine();
                if (current_line == null) {
                    break;
                }
                current_pairs = current_line.split(",", 2);
                current_roll = current_pairs[0];
                current_name = current_pairs[1];
                // Insert the student into newly created course table
                insert_student_query = "INSERT INTO " + course_id + " VALUES ('" + current_roll + "'," + "'n'" + ") ";
                
                stmt.executeUpdate(insert_student_query);
                insert_student_query = "INSERT INTO temp_"+course_id + " VALUES ('" + current_roll + "'," + "'a'" + ",'"+current_roll+"' , 'n') ";
                stmt.executeUpdate(insert_student_query);
                // Now insert course name into users table
                // Get the currently enrolled courses and append the new course to it
                select_student_query = "SELECT courses from users WHERE username = " + "'" + current_roll + "';";
                rs = stmt.executeQuery(select_student_query);
                if (rs.next() == false) {
                    System.out.println("Error inserting course into users table for " + current_roll + " !");
                    // System.exit(-1);
                    continue;
                }
                String current_courses = rs.getString("courses");
                String final_course_list = createFinalCourseString(current_courses, course_id, false);
                // Update the users table with the final_course_list string
                insert_course_query = "UPDATE users SET courses = " + "'" + final_course_list.toString()
                        + "' WHERE username = " + "'" + current_roll + "';";
                stmt.executeUpdate(insert_course_query);
                count++;
                // Debug Line below
                // System.out.println("Roll : " + current_roll + "| Name : " + current_name);

            }
            System.out.println("Insertion Complete !");
            System.out.println("");
        } catch (IOException ex) {
            // abort if the required file is not found
            System.out.println("File " + student_list + " not Found !!!");
            System.out.println("Make Sure that the file is in the same directory as this program and you"
                    + "have entered the name correctly");
            System.exit(-1);
        } catch (SQLException s_ex) {
            System.out.println("Database Exception occured !!! Please Try Again !!!");
            s_ex.printStackTrace();
            System.exit(-1);
        } catch (ClassNotFoundException c_ex) {
            c_ex.printStackTrace();
            System.exit(-1);
        }

    }

    public static String createFinalCourseString(String current_course_String, String courseID, boolean prof) {
        if (current_course_String.equals("n")) {
            return courseID;
        } else {
            if (current_course_String.contains(courseID)) {
                if (prof) {
                    System.out.println("FATAL ERROR !!!");
                    System.out.println("The current professor Already has " + courseID);
                    System.out.println("Aborting !!!");
                    System.exit(-1);
                } else {
                    System.out.println("Student Already Enrolled !");
                    return current_course_String;
                }
            }
        }
        return current_course_String + "$" + courseID;
    }
}
