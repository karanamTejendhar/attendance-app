import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class getClassStats
 */
@WebServlet("/getClassStats")
public class getClassStats extends HttpServlet {
    private static final long serialVersionUID = 1L;
       
    public getClassStats() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String courseParam = "course";
        String courseID = request.getParameter(courseParam);
        PrintWriter output = response.getWriter();
        response.setContentType("text/html");
        if (courseID == null) {
            return ;
        }
        Database db = new Database("proxynt", "devel_user", "devel_Password2000*", courseID);
        String stud_list = db.get_class_stats();
        output.print(stud_list);
        System.out.println(stud_list);
        return ;
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

}
