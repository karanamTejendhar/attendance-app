

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class markAttendance
 */
@WebServlet("/markAttendance")
public class markAttendance extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	private Database markdb ;
    public markAttendance() {
        super();
        // TODO Auto-generated constructor stub
        markdb = null;
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*
		 * roll_number 
		 * unique_code
		 * course_id		 * 
		 * */
		String rollParam = "roll_number";
		String codeParam = "unique_code";
		String courseParam = "course_id";
		String imeiParam = "imei" ;
		String ipadd = "ip" ;
		String uniqueCode = request.getParameter(codeParam) ;
		String rollNumber = request.getParameter(rollParam);
		String courseID = request.getParameter(courseParam);
		String IMEI  =request.getParameter(imeiParam);
		String IPaddress1 = request.getParameter(ipadd) ;
		PrintWriter output = response.getWriter();
		response.setContentType("text/html");
		if(uniqueCode == null || rollNumber == null || courseID == null) {
			output.print("fail");
			return ;
		}
		String attendanceTable = "temp_"+courseID ;

		markdb = new Database("proxynt", "devel_user", "devel_Password2000*", attendanceTable);
		String attendanceStatus = markdb.classAttendance(uniqueCode, rollNumber, courseID, IMEI, IPaddress1) ;
		output.print(attendanceStatus);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
