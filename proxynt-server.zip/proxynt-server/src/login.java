import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

//the url is of the form : http://10.117.144.25/LoginApp/login?user=username&pass=password

@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;	
	private Database db ;
    public login() {
        super();
    	db = new Database("proxynt", "devel_user", "devel_Password2000*", "users");

        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userParam = "user";
		String passParam = "pass";
		String username= request.getParameter(userParam);
		String password = request.getParameter(passParam);
		if (username == null || password == null ) {
			return ;
		}
		// Check if the user is in Database and return a code depending on it
		String checkLogin = db.checkLogin(username, password);
		PrintWriter output = response.getWriter();
		response.setContentType("text/html");
		output.print(checkLogin);
	}
}