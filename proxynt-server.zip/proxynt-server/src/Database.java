import java.sql.*;
import java.sql.Date;
import java.util.*;

import com.mysql.jdbc.exceptions.jdbc4.MySQLIntegrityConstraintViolationException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javafx.scene.control.TabPane;



public class Database {
    private String DATABASE_URI;
    private String username;
    private String password;
    private String table; 
    private static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private Connection db_connection = null;
    
    public Database(String databaseName, String username, String password, String table) {
        this.DATABASE_URI = "jdbc:mysql://localhost/" + databaseName;
        this.username = username;
        this.password = password;
        this.table = table;
        // Create a connection to Database
        try {
            System.out.println(Class.forName(JDBC_DRIVER));
            db_connection = DriverManager.getConnection(DATABASE_URI, username, password);
            System.out.println(db_connection);
        } catch (Exception ex) {
            System.out.println("server error");
            ex.printStackTrace();
        }
    }
    
    public boolean addUser(String username, String name, String isTeacher, String password){
        try {
            Statement stmt = db_connection.createStatement();
            String sql = "INSERT INTO " + table + " VALUES('" + username + "','" + name + "','" + isTeacher
                    +"','" +password+"','n')";
            stmt.executeUpdate(sql);
            return true;
        }catch(SQLException sq) {
            sq.printStackTrace();
            return false;
        }
    }
    
    public String checkLogin(String username, String password) {
        try {
            Statement stmt = db_connection.createStatement();
            System.out.println(stmt);
            String sql = "SELECT username, password, isTeacher, courses FROM " + table + " WHERE username = '" + username + "';";
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next() == false) {
                //username does not exist -- student not enrolled
                System.out.println("rs is null");
                return "fail";
            }
            //rs.next();            
            if (rs.getString("password").equals(password)) {
                String courses = rs.getString("courses") ;
                String type = rs.getString("isTeacher");
                if(type.equals("Y")) {
                    return "teacher$"+courses;
                }
                else {
                    return "student$"+courses;
                }
            } else {
                return "fail";
            }
        } catch (SQLException sq) {
            sq.printStackTrace();
            return "e";
        }
    }
    
    public String startClass (String uniqueCode, String profName, String courseID, String IMEI, String IPaddress) {
        /*
         * check if profName is a teacher
         * check if prof has course with id courseID
         * if(uniqueCode != null)
         *         change the value in database proxynt, table classStatus
         * */
        try {
			String msql = "select * from temp_"+courseID+" ;";
			Statement sm2 = db_connection.createStatement();			
			Statement sm = db_connection.createStatement();			
			ResultSet rs2 = sm.executeQuery(msql); 
			while(rs2.next()) {
				String roll = rs2.getString("roll");
				String query = "UPDATE temp_"+courseID+" SET imei = '"+roll+"' , ipadd = 'n'  WHERE roll = '"+roll+"' ;" ;
				sm2.executeUpdate(query);
			}
            Statement stmt = db_connection.createStatement();
            String colName = courseID;
            String sql = "SELECT courseID, status, ipadd FROM " + table + " WHERE courseID = '" + colName + "';";
            ResultSet rs = stmt.executeQuery(sql) ;
            if (rs.next() == false) {
                //prof is'nt offering the course
                //hence no entry in the classStatus table;
                System.out.println("rs is null");
                return "error" ;
                //teacher isnt offering the course
            }
            
            /*if(rs.getString("status")==null) {
                String modsql = "UPDATE " + table + " SET status = 'n' WHERE courseID = '" + colName + "';";
                stmt.executeUpdate(modsql);
            }*/
            if(!uniqueCode.equals("n")) {
                // Reset previous values;
                String reset = "UPDATE temp_" + courseID + " SET attendance_status = 'a'";
                Statement reset_Statement = db_connection.createStatement();
                reset_Statement.executeUpdate(reset);
                //class is'nt running 
                //modify the table accordingly where status is the uniqueCode
                String modsql = "UPDATE " + table + " SET status = '" + uniqueCode + "' , ipadd = '"+IPaddress+"' WHERE courseID = '" + colName + "';";
                System.out.println(modsql);
                stmt.executeUpdate(modsql);
                //code has been inserted into the database
                return "started" ;
            }
            else {
                // if uniqueCode == null class must be stopped
                // Get the date
                DateFormat dateFormat = new SimpleDateFormat("dd-MM-YYYY");
                
                String today = dateFormat.format(new java.util.Date());
                System.out.println("Stopped class for : " + today);
                // 01. Update the status table to 'n'
                String dmodsql = "UPDATE " + table + " SET status = 'n' WHERE courseID = '" + colName + "';";
                stmt.executeUpdate(dmodsql);
                // 02. Append the class statuses to the main Course Table
                String getStatus = "SELECT * from temp_" + courseID + ";";
                Statement status_stmt = db_connection.createStatement();
                ResultSet statuses = status_stmt.executeQuery(getStatus);
                Statement append_query = db_connection.createStatement();
                String append_query_string = null;
                String new_status = null;
                while (statuses.next()) {
                    String roll = statuses.getString("roll");
                    String attendance_status = statuses.getString("attendance_status");
                    String toBeAppended = today + ":" + attendance_status;
                    append_query_string = "SELECT attendance from " + courseID + " WHERE roll = '" + roll + "';";
                    ResultSet ind_attendance = append_query.executeQuery(append_query_string);
                    if (ind_attendance.next()) {
                        String current_status = ind_attendance.getString("attendance");
                        if(current_status.contains(today)) {
                        	continue;
                        }
                        if (current_status.equals("n")) {
                            new_status = toBeAppended;
                        } else {
                            new_status = toBeAppended + "$" + current_status;
                        }
                    } else {
                        System.out.println("Student '" + roll + "' does not exist in temp_" + courseID);
                    }
                    // Update the attendance to new_status
                    String update_query = "UPDATE " + courseID + " SET attendance = '" + new_status + "' WHERE roll = '" + roll + "';";
                    Statement update_statement = db_connection.createStatement();
                    update_statement.executeUpdate(update_query);
                }
                // Append theses statuses to the main course table
                return "stopped";
            }
        }catch(SQLException sq) {
            sq.printStackTrace();
            return "error";
        }
    }
    public String classAttendance(String uniqueCode, String rollNumber, String courseID, String imei, String ipadd) {
        
        try {
            Statement stmt = db_connection.createStatement();
            /*
             * check if the entered uniqueCode is equal to code against course_id in classStatus
             * */
            String statTable = "classStatus";
            String colName = courseID;
            String sql = "SELECT status, ipadd FROM " + statTable + " WHERE courseID = '" + colName + "';";
            ResultSet rs = stmt.executeQuery(sql) ;
            rs.next();
            if(rs.getString("status").equals(uniqueCode)) {
                //marked the attendance
            	if(!rs.getString("ipadd").equals(ipadd)) {
                    String dmodsql = "UPDATE " + table + " SET attendance_status = 'pr' , imei = '"+imei+"' , ipadd = '"+ipadd+"' WHERE roll = '" + rollNumber + "';";
                    stmt.executeUpdate(dmodsql);
	                System.out.println("caught proxy for " + rollNumber);
	                return "proxy" ;
            	}
            	else {
                    String dmodsql = "UPDATE " + table + " SET attendance_status = 'p' , imei = '"+imei+"' , ipadd = '"+ipadd+"' WHERE roll = '" + rollNumber + "';";
                    stmt.executeUpdate(dmodsql);
            	}
                return "success" ;
            }
            else if (rs.getString("status").equals("n")) {
                return "error2" ;
            }
            else {
                return "failed";
            }
        }catch(SQLException sq) {
            sq.printStackTrace();
            if(sq instanceof MySQLIntegrityConstraintViolationException) {
            	Statement stmt;
				try {
					stmt = db_connection.createStatement();
	            	String dmodsql = "UPDATE " + table + " SET attendance_status = 'pr' , imei = '"+rollNumber+"' , ipadd = '"+ipadd+"' WHERE roll = '" + rollNumber + "';";
	                stmt.executeUpdate(dmodsql);
	                System.out.println("caught proxy for " + rollNumber);
	                return "proxy" ;
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

            }
            return "error";
        }
    }

    public String getStudentStats(String roll, String course) {
        try {
            Statement stmt = db_connection.createStatement();
            String student_query = "SELECT attendance FROM " + course + " WHERE roll = '" + roll + "';";
            //System.out.println(student_query);
            ResultSet rs = stmt.executeQuery(student_query);
            rs.next();
            return rs.getString("attendance");
        } catch (SQLException sq) {
            sq.printStackTrace();
            return null;
        }

    }

    public String get_class_stats() {
        try{
            Statement stmt = db_connection.createStatement();
            Statement stmt1 = db_connection.createStatement();
            String roll_query = "SELECT roll FROM " + table  + " ;";
            ResultSet rs_roll = stmt.executeQuery(roll_query);
            ResultSet rs_name = null;
            String rollNum, name, single_item;
            String name_query;
            StringBuilder retVal = new StringBuilder();
            while(rs_roll.next()==true) {
                rollNum = rs_roll.getString("roll");
                name_query = "SELECT name FROM users WHERE username = '" + rollNum + "';";
//                System.out.println(name_query);
                rs_name = stmt1.executeQuery(name_query);
                if (rs_name.next() == false) {
                    name = "N/A";
                } else {
                    name = rs_name.getString("name");
                }
                single_item = rollNum + ":" + name;
                if (retVal.toString().length() == 0) {
                    retVal.append(single_item);
                } else {
                    retVal.append("$" + single_item);
                }
            }
//            System.out.println(retVal.toString());
            return retVal.toString();
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public void close() throws SQLException{
        db_connection.close();
    }

	public String calculateProxies(String courseID) {
		
		try {
			Statement stmt = db_connection.createStatement() ;
			String sql = "SELECT roll, attendance_status FROM temp_"+table+" ;";
			ResultSet rs = stmt.executeQuery(sql);
			String rollNumber, proxyItem;
			StringBuilder sb = new StringBuilder();
			while(rs.next()==true) {
				if(rs.getString("attendance_status").equals("pr")) {
					rollNumber = rs.getString("roll");
	                proxyItem = rollNumber;
	                if (sb.toString().length() == 0) {
	                    sb.append(proxyItem);
	                } else {
	                    sb.append("$" + proxyItem);
	                }
				}
			}
			if(sb.toString()==null) {
				return "n" ;
			}
			return  sb.toString();			
		}catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
    
}
