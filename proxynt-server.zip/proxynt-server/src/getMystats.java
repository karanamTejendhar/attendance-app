import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class getMystats
 */
@WebServlet("/getMystats")
public class getMystats extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private Database db;

    public getMystats() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userParam = "user";
        String courseParam = "course";
        String rollNo = request.getParameter(userParam);
        String course = request.getParameter(courseParam);
        if (rollNo == null||course == null) {
            return ;
        }
        // Create a Database connection to main course table and get the students stats
        db = new Database("proxynt", "devel_user", "devel_Password2000*", course);
        String stats = db.getStudentStats(rollNo, course);
        // getStudentStats returns return a string of the form <date>:<status>$<date>:<status>$... if everything is correct
        // if returns null otherwise
        PrintWriter output = response.getWriter();
        response.setContentType("text/html");
        output.print(stats);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        return ;
    }

}