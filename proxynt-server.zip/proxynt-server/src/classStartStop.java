import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class classStartStop
 */
@WebServlet("/classStartStop")
public class classStartStop extends HttpServlet {
	private static final long serialVersionUID = 1L; 
    /**
     * @see HttpServlet#HttpServlet()
     */
	//private Database userdb ;
	private Database statdb ;
    public classStartStop() {
        super();
        //userdb = new Database("proxynt", "devel_user", "devel_Password2000*", "users");
        statdb = new Database("proxynt", "devel_user", "devel_Password2000*", "classStatus");
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//unique_code : null = stop class, code = replace in classStatus
		//prof_username
		//course_id
		String codeParam = "unique_code";
		String profParam = "prof_username";
		String courseParam = "course_id"; 
		String imeiParam = "imei" ;
		String ipadd = "ip" ;
		String uniqueCode = request.getParameter(codeParam) ;
		String profName = request.getParameter(profParam);
		String courseID = request.getParameter(courseParam);
		String IMEI  =request.getParameter(imeiParam);
		String IPaddress = request.getParameter(ipadd) ;
		PrintWriter output = response.getWriter();
		response.setContentType("text/html");
		String classStat = statdb.startClass(uniqueCode, profName, courseID, IMEI, IPaddress);
		if(!classStat.equals("error")) {
			output.print("success") ;
		}
		else {
			output.print("fail");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
