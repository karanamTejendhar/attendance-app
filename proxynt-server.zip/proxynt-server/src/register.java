
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//the url is of the form : http:10.117.144.25/LoginApp/login?user=username&pass=password

@WebServlet("/register")
public class register extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Database db;
	
    public register() {
        super();
        db = new Database("proxynt", "devel_user", "devel_Password2000*", "users");
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userParam = "user";
		String passParam = "pass";
		String nameParam = "name";
		String isTeacherParam = "isTeacher";
		String username= request.getParameter(userParam);
		String password = request.getParameter(passParam);
		String name = request.getParameter(nameParam);
		String isTeacher= request.getParameter(isTeacherParam);
		PrintWriter output = response.getWriter();
		response.setContentType("text/html");
		if (username == null || password == null || name == null  || isTeacher == null) {
			return ;
		}
		// Check if the user is in Database and return a code depending on it
		boolean addUser = db.addUser(username, name, isTeacher, password);
		if (addUser) {
			output.print("200");
		} else {
			output.print("404");
		}	
	}
}