Attendance taking app 

Database name : proxynt 
table names : classStatus :- to store the uniqueCode and ipaddress of teacher which helps to mark proxies
		    users :- to store teachers and students username and password , for login and register
		    addCourse.java file will create the remaining tables
		    		course_id :- storing the attendances of students
		    		temp_course_id :- storing the temporary attendances and proxies

code will run in eclipse ide

host server on Apache tomcat v9.0, configured to run on eclipse

Code doesn't work on its own. host on tomcat server. 

		

