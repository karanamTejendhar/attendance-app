package com.example.proxynt;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.util.HashMap;

public class SplashScreen extends AppCompatActivity {

    private CredentialManager cd;
    private NetworkManager networkManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        // Set Network Permissions
        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 8)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            //your codes here

        }

        init();

        // The splash screen not only makes the app look good,
        // It also sets up the network activities in the background, so that the user does not wait
        // While Displaying the screen, check if the user is not logged in previously
        SharedPreferences sp = getSharedPreferences("LOGIN", MODE_PRIVATE);
        HashMap<String, String> login_creds = new HashMap<>();
        login_creds.put("username", sp.getString("username", null));
        login_creds.put("password", sp.getString("password", null));
        if (login_creds.get("username") == null) {
            // Send the user to the login screen
            openLoginActivity();

        } else {
            try {
                HashMap<String, String> login_values = networkManager.Login(login_creds.get("username"), login_creds.get("password"));
                if (login_values == null) {
                    showToast("Network Error. Please connect to Institute Wifi !!!");
                } else {
                    if (login_values.get("status").equals("success")) {
                        String usertype = login_values.get("type");
                        String courses = login_values.get("courses");
                        sp = getSharedPreferences("LOGIN", MODE_PRIVATE);
                        SharedPreferences.Editor ed = sp.edit();
                        ed.putString("usertype", usertype);
                        ed.putString("courses", courses);
                        ed.commit();
                        showToast("Login Successful !");
                        if (usertype.equals("teacher")) {
                            openTeacherHomeActivity();
                        } else if (usertype.equals("student")) {
                            openStudentHomeActivity();
                        }
                    } else if (login_values.get("status").equals("fail")) {
                        showToast("Failed to Login !");
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    // Initialiser function
    private void init() {
        cd = new CredentialManager();
        networkManager = new NetworkManager(getString(R.string.ipaddress), 6969);
    }

    // Helper Functions

    public void openTeacherHomeActivity() {
        // This function opens the Homepage
        Intent intent = new Intent(this, TeacherHomePage.class);
        startActivity(intent);
        finish();
    }

    public void openStudentHomeActivity() {
        // This function opens the Homepage
        Intent intent = new Intent(this, StudentHomePage.class);
        startActivity(intent);
        finish();
    }

    private void openLoginActivity() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent mainIntent = new Intent(SplashScreen.this, Login.class);
                startActivity(mainIntent);
                finish();
            }
        }, 1500);
    }

    private void showToast(String message) {
        Toast.makeText(this, message,Toast.LENGTH_LONG).show();
    }
}
