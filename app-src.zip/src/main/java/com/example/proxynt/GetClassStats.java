package com.example.proxynt;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;


public class GetClassStats extends Fragment {

    private OnFragmentInteractionListener mListener;
    private View main_view;
    private Button get_stat_button;
    private ListView list;
    private Spinner spinner;
    private ArrayAdapter<String> spinner_adapter;
    private TeacherListAdapter list_adapter;
    private NetworkManager networkManager;
    private SharedPreferences sp;
    private SharedPreferences.Editor ed;

    public GetClassStats() {
        // Required empty public constructor
    }

    public static GetClassStats newInstance(String param1, String param2) {
        GetClassStats fragment = new GetClassStats();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        main_view = inflater.inflate(R.layout.fragment_get_class_stats, container, false);
        // Call init() only after assiging the main_view
        init();

        // Custom OnClickListener is already implemented
        get_stat_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String course_id = spinner.getSelectedItem().toString();
                    String stud_list = networkManager.getClassStats(course_id);
                    list.setSelection(0);
                    if (course_id.equals("n_error")) {
                        showToast("Network Error !");
                        return;
                    } else {
                        String[] splitted = stud_list.split("\\$");
                        ArrayList<TeacherListItem> item_list = new ArrayList<>();
                        for (String combo : splitted) {
                            String name = combo.split("\\:")[1];
                            String roll = combo.split("\\:")[0];
                            item_list.add(new TeacherListItem(name, roll));
                        }
                        TeacherListItem[] t_items = item_list.toArray(new TeacherListItem[item_list.size()]);
                        list_adapter = new TeacherListAdapter(getActivity(), R.layout.teacher_list_row, t_items, course_id);
                        list.setAdapter(list_adapter);
                        list.setSelection(0);
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    showToast("Network Error !");
                    return ;
                }
            }
        });
        return main_view;
    }

    // INITIALISATION FUNCTION
    public void init() {
        sp = getActivity().getSharedPreferences("LOGIN", MODE_PRIVATE);
        ed = sp.edit();
        String[] courses = sp.getString("courses", null).split("\\$", 20);
        list = main_view.findViewById(R.id.teacher_list_view);
        spinner = main_view.findViewById(R.id.stat_teacher_spinner);
        get_stat_button = main_view.findViewById(R.id.get_class_stats_button);
        spinner_adapter = new ArrayAdapter<>(getActivity(), R.layout.spinner_layout, courses);
        spinner_adapter.setDropDownViewResource(R.layout.spinner_layout);
        spinner.setAdapter(spinner_adapter);
        networkManager = new NetworkManager(getString(R.string.ipaddress), 6969);
    }


    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    public void showToast(String message) {
        Toast.makeText(getActivity(), message,Toast.LENGTH_LONG).show();
    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
