package com.example.proxynt;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

//The Student HomePage contains 3 Tabs : Start Class, Class Stats, About

public class TeacherTabManager extends FragmentPagerAdapter {

    public TeacherTabManager(FragmentManager fm){
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new StartClass();
            case 1:
                return new GetClassStats();
            case 2:
                return new About();
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        // There are three Tabs in total
        return 3;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position){
            case 0:
                return "Start Class";
            case 1:
                return "Class Statistics";
            case 2:
                return "About";
            default:
                return null;
        }
    }
}
