package com.example.proxynt;

import android.net.Uri;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;

public class StudentHomePage extends FragmentActivity implements About.OnFragmentInteractionListener,
        GetMyStats.OnFragmentInteractionListener, MarkAttendance.OnFragmentInteractionListener {

    TabLayout tablayout;
    ViewPager viewpager;
    StudentTabManager pagerAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_home_page);
        //initialise the components
        init();


    }

    public void init() {
        tablayout = findViewById(R.id.StudentTabLayout);
        viewpager = findViewById(R.id.StudentViewPager);
        // to stop tab refreshing on change
        viewpager.setOffscreenPageLimit(5);
        pagerAdapter = new StudentTabManager(getSupportFragmentManager());
        viewpager.setAdapter(pagerAdapter);
        tablayout.setupWithViewPager(viewpager);
        tablayout.setTabGravity(TabLayout.GRAVITY_FILL);

    }

    @Override
    public void onFragmentInteraction(Uri uri) {

    }
}


