package com.example.proxynt;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.Toast;

import static android.content.Context.MODE_PRIVATE;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link About.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link About#newInstance} factory method to
 * create an instance of this fragment.
 */
public class About extends Fragment {
    private OnFragmentInteractionListener mListener;
    View main_view;
    Button logout;
    ConstraintLayout layout;
    SharedPreferences sp;
    SharedPreferences.Editor ed;

    public About() {
        // Required empty public constructor
    }
    public static About newInstance() {
        About fragment = new About();
        Bundle args = new Bundle();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        this.main_view = inflater.inflate(R.layout.fragment_about, container, false);
        this.logout = this.main_view.findViewById(R.id.logout_button);
        this.layout = this.main_view.findViewById(R.id.about_layout);
        sp = getActivity().getSharedPreferences("LOGIN", MODE_PRIVATE);
        ed = sp.edit();
       // Set the button Listener
        this.logout.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // add the user credentials
                ed.putString("username", null);
                ed.putString("password", null);
                ed.putString("usertype", null);
                ed.commit();
                showToast("Successfully Logged out !!!");
                // Take the user back to Login Screen
                openLoginActivity(main_view);
            }
        });
        return main_view;
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }


    public void openLoginActivity(View view) {
        // This function opens the Homepage
        Intent intent = new Intent(getActivity(), Login.class);
        startActivity(intent);
        getActivity().finish();
    }

    public void showToast(String message) {
        Toast.makeText(getActivity(), message,Toast.LENGTH_LONG).show();
    }
}
