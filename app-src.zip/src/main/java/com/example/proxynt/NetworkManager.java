package com.example.proxynt;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class NetworkManager {
    // This class entirely manages the Network part of the app !!!
    String server_url; // FORMAT : https://0.0.0.0/proxynt, no slash at the last position !!!
    int server_port;
    String charset;

    public NetworkManager(String server_url, int server_port) {
        this.server_port = server_port;
        this.server_url = server_url;
        this.charset = "UTF-8";
    }

    public void sendPostResquest(String[] params) {


    }

    public URLConnection sendGetRequest(String system, HashMap<String, String> params){
        // This Function sends a HTTP Post request to server
        // The server contains the given params from the parameter HashMap
        // The server returns a URLConnection to the caller function
        // Parse the parameters and create a query String
        StringBuilder paramString = new StringBuilder(server_url+ "/" +system + "?");
        String singleParam = "";
        for (HashMap.Entry<String, String> entry : params.entrySet()) {
            singleParam = entry.getKey() + "=" + entry.getValue() + "&";
            paramString.append(entry.getKey() + "=" + entry.getValue() + "&");
        }
        String queryString = paramString.deleteCharAt(paramString.length() -1).toString();
//        System.out.println(encodedUrl);
        URLConnection connection = null;
        try {
            connection = new URL(queryString).openConnection();
            connection.setRequestProperty("Accept-Charset", charset);
            connection.setConnectTimeout(7000);
            connection.setReadTimeout(7000);

        } catch (java.net.ConnectException ex) {
            ex.printStackTrace();
            return null;
        } catch (MalformedURLException ex) {
            ex.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return connection;
        // The caller function takes responsibility to close the connection !!!
    }


    public HashMap<String, String> Login(String username, String password) throws Exception{
        // The Login function sends the username and HASHED password to the server for verification
        // It recieves a hashmap of the server response

        String hashedPassword = SHA256(password);
        HashMap<String, String> params = new HashMap<String, String>();
        params.put("user", username);
        params.put("pass", hashedPassword);
        URLConnection connection = sendGetRequest("login", params);
        if (connection == null) {
            return null; // network error
        }
        HashMap<String, String> result = null;
        result = new HashMap<>();
        try{
            String response = readStream(connection.getInputStream());
//            String response = "student$cs21004$CS25002$CS21005";

            if (response.equals("fail")) {
                // Login Failed
                result.put("status", "fail");
                result.put("type", null);
                result.put("courses", null);
                return result;
            }else {
                String[] decoded_response = response.split("\\$", 2);
                System.out.println(decoded_response[1]);
                result.put("status", "success");
                result.put("type", decoded_response[0]);
                result.put("courses", decoded_response[1]);
                return result;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
//            connection.getInputStream().close();
//            ((HttpURLConnection)connection).disconnect();
        }

    }

    public String Register(String username, String name, String isTeacher, String password) throws Exception {
        String hashedPassword = SHA256(password);
        HashMap<String, String> params = new HashMap<>();
        params.put("user", username);
        params.put("pass", hashedPassword);
        params.put("name", name);
        params.put("isTeacher", isTeacher);
        URLConnection connection = sendGetRequest("register", params);
        if (connection == null){
            return "p"; // network error
        }
        String retVal;
        String response = readStream(connection.getInputStream());
        if (response.equals("200")) {
            retVal = "y";
        } else {
            retVal = "n";
        }
        connection.getInputStream().close();
        ((HttpURLConnection)connection).disconnect();
        return retVal;
    }

    public String ClassStartStop(String course_id, String prof_username, String unique_code, String ipaddress) throws Exception {
        // This function sends a get request to the server to start/stop the class
        // It needs the prof_username, course_id, uniqueCode
        // If the unique code is null, it means stop the class
        // otherwise start a class with the code
        HashMap<String, String> params = new HashMap<>();
        params.put("course_id", course_id);
        params.put("prof_username", prof_username);
        params.put("unique_code", unique_code);
        params.put("ip", ipaddress);
//        params.put("imei", imei);
        URLConnection connection = sendGetRequest("classStartStop", params);
        if (connection == null) {
            return "n_error";
        }
        String response = readStream(connection.getInputStream());
        // The response is either success or fail
        // The startClass activity takes care of showing the notification based on the the button context
        return response;
    }


    public String markAttendance(String username, String course_id, String unique_code, String imei, String ipaddress) throws Exception {
        // send the student's location and username, course_id to the server
        HashMap<String, String> params= new HashMap<>();
        params.put("roll_number", username);
        params.put("course_id", course_id);
        params.put("unique_code", unique_code);
        params.put("imei", imei);
        params.put("ip", ipaddress);
        URLConnection connection = sendGetRequest("markAttendance", params);
        if (connection == null){
            return "n_error"; // network error
        }
        String response = readStream(connection.getInputStream());
        ((HttpURLConnection)connection).disconnect();
        return response;
    }

    public String getMyStats(String roll, String course) throws Exception{
        HashMap<String, String> params = new HashMap<>();
        params.put("user", roll);
        params.put("course", course);
        URLConnection connection = sendGetRequest("getMystats", params);
        if (connection == null) {
            return "n_error";
        }
        String response = readStream(connection.getInputStream());
        ((HttpURLConnection)connection).disconnect();
        return response;
    }

    public String getClassStats(String course_id) throws Exception{
        HashMap<String, String> params = new HashMap<>();
        params.put("course", course_id);
        URLConnection connection = sendGetRequest("getClassStats", params);
        if (connection == null) {
            return "n_error";
        }
        String response = readStream(connection.getInputStream());
        ((HttpURLConnection)connection).disconnect();
        System.out.println(response);
        return response;
    }

    public String getProxies(String courseID) throws Exception{
        HashMap<String, String> params = new HashMap<>();
        params.put("course_id", courseID);
        URLConnection connection = sendGetRequest("getProxies", params);
        if (connection == null) {
            return "n_error";
        }
        String response = readStream(connection.getInputStream());
        ((HttpURLConnection)connection).disconnect();
        return response;

    }


    // Helper Functions
    private String SHA256(String input) throws NoSuchAlgorithmException, UnsupportedEncodingException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] messageDigest = md.digest(input.getBytes("UTF-8"));
        BigInteger no = new BigInteger(1, messageDigest);
        String hashtext = no.toString(16);
        while (hashtext.length() < 32) {
            hashtext = "0" + hashtext;
        }
        return hashtext;
    }

    private String readStream(InputStream in) {
        Scanner s = new Scanner(in).useDelimiter("\\A");
        String result = s.hasNext() ? s.next() : "";
        return result;
    }


}
