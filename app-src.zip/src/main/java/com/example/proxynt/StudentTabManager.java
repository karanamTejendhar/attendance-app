package com.example.proxynt;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

//The Student HomePage contains 3 Tabs : Mark Attendance, My Statistics, About

public class StudentTabManager extends FragmentPagerAdapter {


    public StudentTabManager(FragmentManager fm){
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                return new MarkAttendance();
            case 1:
                return new GetMyStats();
            case 2:
                return new About();
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        // There are three Tabs in total
        return 3;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position){
            case 0:
                return "Mark Attendance";
            case 1:
                return "My Statistics";
            case 2:
                return "About";
            default:
                return null;
        }
    }
}
