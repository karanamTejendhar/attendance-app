package com.example.proxynt;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashMap;

public class CredentialManager {

    String LOGIN_CREDENTIALS_KEY = "LOGIN";

    public CredentialManager() {}

    public void putLoginCredentials(Context context, String username, String password) {
        SharedPreferences sp = context.getSharedPreferences(LOGIN_CREDENTIALS_KEY, context.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString("username", username);
        ed.putString("password", password);
        return ;
    }

    public HashMap<String, String> getLoginCredentials(Activity a) {
        SharedPreferences sp = a.getSharedPreferences(LOGIN_CREDENTIALS_KEY, a.MODE_PRIVATE);
        HashMap<String, String> retVal = new HashMap<String, String>();
        if(sp == null) {
            retVal.put("username", null);
            retVal.put("password", null);
            return retVal;
        }

        String username = sp.getString("username", null);
        String password = sp.getString("password", null);

        retVal.put("username", username);
        retVal.put("password", password);
        return retVal;
    }

    public void DeleteLoginCredentials(Activity a) {
        SharedPreferences sp = a.getSharedPreferences(LOGIN_CREDENTIALS_KEY, a.MODE_PRIVATE);
        SharedPreferences.Editor ed = sp.edit();
        ed.putString("username", null);
        ed.putString("password", null);
        return ;
    }
}
