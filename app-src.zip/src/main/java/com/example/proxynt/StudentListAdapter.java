package com.example.proxynt;

import android.app.Activity;
import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class StudentListAdapter extends ArrayAdapter<StudentListItem> {
    Context context;
    int resourceLayoutID;
    StudentListItem[] items;

    public StudentListAdapter(Context context, int resourceLayoutID, StudentListItem[] items) {
        // Don't forget to send the items to super, otherwise list will be empty
        super(context, resourceLayoutID, items);
        this.context = context;
        this.items = items;
        this.resourceLayoutID = resourceLayoutID;
        System.out.println("debug");
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        Holder holder = null;
        if (row == null) {
            // inflate the view
            LayoutInflater inflater = ((Activity)context).getLayoutInflater();
            row = inflater.inflate(resourceLayoutID, parent, false);
            holder = new Holder();
            holder.date = row.findViewById(R.id.date);
            holder.status = row.findViewById(R.id.status);
            row.setTag(holder);
        } else {
            holder = (Holder)row.getTag();
        }
        StudentListItem item = items[position];
        System.out.println("Setting Adapter");
        holder.date.setText(item.date);
        // Add code to change the color of status based on the absent of present
        holder.status.setText(item.status);
        item.status = item.status.toUpperCase();
        if (item.status.equals("P")) {
            holder.status.setTextColor(ContextCompat.getColor(context, R.color.colorAccent));
            holder.date.setTextColor(ContextCompat.getColor(context, R.color.colorAccent));
        }
        return row;
    }

    @Override
    public int getViewTypeCount() {

        return getCount();
    }

    @Override
    public int getItemViewType(int position) {

        return position;
    }

    static class Holder{
        TextView date;
        TextView status;
    }
}