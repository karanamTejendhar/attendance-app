package com.example.proxynt;

import android.content.SharedPreferences;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class IndStats extends AppCompatActivity {

    private TextView p_percentage;
    private TextView p_proxies;
    private TextView stud_details;
    private ListView list;
    private ConstraintLayout layout;
    private String name;
    private String roll;
    private String courseID;
    private NetworkManager networkManager;
    StudentListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ind_stats);
        layout = findViewById(R.id.indStats_layout);
        layout.setBackground(ContextCompat.getDrawable(this, R.drawable.gradient_blue));

        init();
        list.setSelection(0);
        // set the data for components
        stud_details.setText(name + "(" + roll + ")");
        try {
            String stud_attendance = networkManager.getMyStats(roll, courseID);
            if (stud_attendance.equals("n_error")) {
                showToast("Network Error");
            } else if (stud_attendance.equals("n")) {
                StudentListItem[] items = new StudentListItem[] {new StudentListItem("Zero Attendance", "0"),};
                p_proxies.setText("None");
                p_percentage.setText("0%");
                adapter = new StudentListAdapter(this, R.layout.student_list_row, items);
                list.setAdapter(adapter);
                list.setSelection(0);
                return ;
            } else {
                String []splitted = stud_attendance.split("\\$");
                // each element of the array is <date>:<status>
                String date, status;
                ArrayList<StudentListItem> temp_list = new ArrayList<>();
                int c_count = 0;
                int p_count = 0;
                int pr_count = 0;
                for (String combo:splitted) {
                    c_count++;
                    date = combo.split("\\:")[0];
                    status = combo.split("\\:")[1];
                    if (status.equals("p")) {
                        p_count++;
                    } else if (status.equals("pr")) {
                        pr_count++;
                    }
                    temp_list.add(new StudentListItem(date, status.toUpperCase()));
                }
                p_percentage.setText("Attendance : " + String.valueOf(100 * p_count/c_count) + "%(" + p_count + "/" + c_count+ ")");
                p_proxies.setText("Proxies : " + String.valueOf(pr_count));
                StudentListItem[] items = temp_list.toArray(new StudentListItem[temp_list.size()]);
                adapter = new StudentListAdapter(this, R.layout.student_list_row, items);
                list.setAdapter(adapter);
                list.setSelection(0);
                return ;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            showToast("Network Error !");
        }


    }

    public void init() {
        stud_details = findViewById(R.id.stud_details);
        p_percentage = findViewById(R.id.p_percent);
        p_proxies = findViewById(R.id.p_proxies);
        Bundle extras = getIntent().getExtras();
        roll = extras.getString("roll");
        name = extras.getString("name");
        courseID = extras.getString("course");
        networkManager = new NetworkManager(getString(R.string.ipaddress), 6969);
        list = findViewById(R.id.t_list_view);
    }


    public void showToast(String message) {
        Toast.makeText(this, message,Toast.LENGTH_LONG).show();
    }
}
