package com.example.proxynt;

public class StudentListItem {
    public String date;
    public String status;

    public StudentListItem(String date, String status) {
        this.date = date;
        this.status = status;
    }
}
