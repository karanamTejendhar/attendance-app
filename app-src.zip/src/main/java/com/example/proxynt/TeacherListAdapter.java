package com.example.proxynt;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

public class TeacherListAdapter extends ArrayAdapter<TeacherListItem> {
    Context context;
    int resourceLayoutID;
    TeacherListItem[] items;
    String courseID;

    public TeacherListAdapter(Context context, int resourceLayoutID, TeacherListItem[] items, String courseId) {
        super(context, resourceLayoutID, items);
        this.context = context;
        this.resourceLayoutID = resourceLayoutID;
        this.items = items;
        this.courseID = courseId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View row = convertView;
        Holder holder = null;
        if (row == null) {
            LayoutInflater inflater = ((Activity)context).getLayoutInflater();
            row = inflater.inflate(resourceLayoutID, parent, false);
            holder = new Holder();
            holder.name = row.findViewById(R.id.name);
            holder.roll_number = row.findViewById(R.id.roll_number);
            row.setTag(holder);
        } else {
            holder = (Holder)row.getTag();
        }
        final TeacherListItem item = items[position];
        holder.name.setText(item.name);
        holder.roll_number.setText(item.roll_number);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, IndStats.class);
                intent.putExtra("name", item.name);
                intent.putExtra("roll", item.roll_number);
                intent.putExtra("course", courseID);
                context.startActivity(intent);
            }
        });
        return row;

    }


    @Override
    public int getViewTypeCount() {

        return getCount();
    }

    @Override
    public int getItemViewType(int position) {

        return position;
    }


    static class Holder{
        TextView name;
        TextView roll_number;
    }
}
