package com.example.proxynt;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import static android.content.Context.MODE_PRIVATE;
import static android.content.Context.NETWORK_STATS_SERVICE;

public class MarkAttendance extends Fragment{

    private View main_view;
    private OnFragmentInteractionListener mListener;
    private EditText attendance_code;
    private Button attend_button;
    private Spinner course_select_spinner;
    private NetworkManager networkManager;
    private String imei;
    private String ipaddress;
    private WifiManager wifiManager;
    private TelephonyManager telephonyManager;
    private final int MY_PHONE_PERMISSION = 1;

    public MarkAttendance() {
        // Required empty public constructor
    }

    public static MarkAttendance newInstance(String param1, String param2) {
        MarkAttendance fragment = new MarkAttendance();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        main_view = inflater.inflate(R.layout.fragment_mark_attendance, container, false);
        // Call init() only after assigning the main_view
        init();

       // get the imei
        try {

            telephonyManager = (TelephonyManager) getActivity().getSystemService(Context.TELEPHONY_SERVICE);
            imei = telephonyManager.getDeviceId();

        } catch (SecurityException se) {
            if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                // Location Permission is not granted
                // Explicitly ask for user permission
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_PHONE_STATE}, MY_PHONE_PERMISSION);
            }
            telephonyManager = (TelephonyManager) getActivity().getSystemService(Context.TELEPHONY_SERVICE);
            imei = telephonyManager.getDeviceId();
        }

        attend_button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                SharedPreferences sp = getActivity().getSharedPreferences("LOGIN", MODE_PRIVATE);
                String username = sp.getString("username", null);
                String course_id = course_select_spinner.getSelectedItem().toString();
                String unique_code = attendance_code.getText().toString();
                wifiManager = (WifiManager)getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                WifiInfo wifiInf = wifiManager.getConnectionInfo();
                int i_addr = wifiInf.getIpAddress();
                String f_ipaddress= String.format("%d.%d.%d.%d", (i_addr & 0xff),(i_addr >> 8 & 0xff),(i_addr >> 16 & 0xff),(i_addr >> 24 & 0xff));
                ipaddress = f_ipaddress.split("\\.")[0] + f_ipaddress.split("\\.")[1];
                System.out.println(ipaddress);
                String attend_status;

                // Get IMEI (For Safety)
                try {

                    telephonyManager = (TelephonyManager) getActivity().getSystemService(Context.TELEPHONY_SERVICE);
                    imei = telephonyManager.getDeviceId();

                } catch (SecurityException se) {
                    if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                        // Location Permission is not granted
                        // Explicitly ask for user permission
                        ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_PHONE_STATE}, MY_PHONE_PERMISSION);
                    }
                    telephonyManager = (TelephonyManager) getActivity().getSystemService(Context.TELEPHONY_SERVICE);
                    imei = telephonyManager.getDeviceId();
                }
                try{
                    attend_status = networkManager.markAttendance(username, course_id, unique_code, imei, ipaddress);
                    System.out.print("IMEI : " + imei);
                } catch (Exception ex) {
                    showToast("Attendance Failed !");
                    return ;
                }
                // send this info to the server so that the student can mark attendance
                // if the attendance is marked succesfully, so success toast
                if (attend_status.equals("success")) {
                    showToast("Attendance Marked Successfully !");
                } else if(attend_status.equals("error2")) {
                    showToast("Class Not Running currently");
                } else if(attend_status.equals("n_error")) {
                    showToast("Network Error");
                } else if(attend_status.equals("proxy")) {
                    showToast("Proxy Recorded. Contact your professor Immediately !");
                }else{
                        // show fail toast
                        showToast("Failed to mark Attendance. Try Again !");
                    }
                }
        });

        return main_view;
    }


    public void showToast(String message) {
        Toast.makeText(getActivity(), message , Toast.LENGTH_SHORT).show();
    }


    public void init() {
        attend_button = this.main_view.findViewById(R.id.attend_button);
        attendance_code = this.main_view.findViewById(R.id.attendance_code);
        course_select_spinner = this.main_view.findViewById(R.id.student_course_spinner);
        SharedPreferences sp = getActivity().getSharedPreferences("LOGIN", MODE_PRIVATE);
        networkManager = new NetworkManager(getString(R.string.ipaddress), 6969);
        String courses = sp.getString("courses", null);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_layout, courses.split("\\$", 20));
        adapter.setDropDownViewResource(R.layout.spinner_layout);
        course_select_spinner.setAdapter(adapter);
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
