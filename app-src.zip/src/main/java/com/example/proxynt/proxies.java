package com.example.proxynt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class proxies extends AppCompatActivity {

    private ListView list;
    private NetworkManager networkManager;
    private StudentListAdapter adapter = null;
    private ArrayList<StudentListItem> items = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_proxies);

        init();


    }

    public void init() {
        networkManager = new NetworkManager(getString(R.string.ipaddress), 6969);
        list = findViewById(R.id.proxy_list);
        list.setSelection(0);
        try {
            String proxy_list = networkManager.getProxies(getIntent().getStringExtra("courseID"));
            System.out.println("proxies : " + proxy_list);
            if (proxy_list.equals("n_error")) {
                showToast("Network Error !");
                return ;
            } else{
                if (proxy_list.equals("n") || proxy_list == null || proxy_list.equals("")) {
                    items.add(new StudentListItem("No Proxies", ""));
                    adapter = new StudentListAdapter(this, R.layout.student_list_row, items.toArray(new StudentListItem[items.size()]));
                    list.setSelection(0);
                    return ;
                } else {
                    String []item_list = proxy_list.split("\\$");
                    for (String item:item_list) {
                        if(item != null) {
                            items.add(new StudentListItem(item, "Pr"));
                        }
                    }
                    adapter = new StudentListAdapter(this, R.layout.student_list_row, items.toArray(new StudentListItem[items.size()]));
                    list.setAdapter(adapter);
                    list.setSelection(0);
                }
            }
            return ;
        } catch (Exception ex) {
            ex.printStackTrace();
            showToast("Unexpected Error Occured!");
        }
    }


    public void showToast(String message) {
        Toast.makeText(this, message,Toast.LENGTH_LONG).show();
    }

}
