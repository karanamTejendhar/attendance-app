package com.example.proxynt;

import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.drawable.AnimationDrawable;
import android.os.StrictMode;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    ConstraintLayout mainLayout;
    EditText username;
    EditText password;
    EditText enterName;
    EditText confirm_password;
    Button register_button;
    NetworkManager networkManager;
    CheckBox areYouAStudent;

    // Disable gradient banding
    @Override
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Window window = getWindow();
        window.setFormat(PixelFormat.RGBA_8888);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // Set Network Permissions
        int SDK_INT = android.os.Build.VERSION.SDK_INT;
        if (SDK_INT > 8)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                    .permitAll().build();
            StrictMode.setThreadPolicy(policy);
            //your codes here

        }

        // Initialise components
        init();
        // Start Animation
        animateBackground();
        // Change the text of username if areYouAStudentIsSelected
        areYouAStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (((CheckBox)v).isChecked()) {
                    username.setHint(R.string.studentUsernameHint);
                } else {
                    username.setHint(R.string.username_enterhint);
                }
            }
        });
        // Button Listeners
        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Validate Forms and start network activity
                if (!checkErrors()) {
                    // display toast and get back into login activity
                    String user = username.getText().toString().toUpperCase();
                    String pass = password.getText().toString();
                    String name = enterName.getText().toString();
                    String isTeacher = "Y";
                    if (areYouAStudent.isChecked()) {
                        isTeacher = "N";
                    }
                    try {
                        String registerStatus = networkManager.Register(user, name, isTeacher, pass);
                        if (registerStatus == "y") {
                            showToast("Registration Successful");
                            goToLogin();
                        } else if (registerStatus == "n") {
                            showToast("Failed to Register !");
                        } else {
                            showToast("Network Error");
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                return ;
            }
        });
    }

    // Helper Functions
    public void init() {
        username = (EditText)findViewById(R.id.register_username);
        password = (EditText)findViewById(R.id.register_password);
        enterName = (EditText)findViewById(R.id.enterName);
        confirm_password = (EditText) findViewById(R.id.confirm_password);
        register_button = (Button)findViewById(R.id.register_button);
        mainLayout = (ConstraintLayout)findViewById(R.id.registerLayout);
        areYouAStudent = (CheckBox) findViewById(R.id.areYouAStudent);
        networkManager = new NetworkManager(getString(R.string.ipaddress), 6969);
        // set default registration to student form
        areYouAStudent.setChecked(true);
        username.setHint(R.string.studentUsernameHint);
    }

    public void animateBackground() {
        // Set background animation
        AnimationDrawable animation = (AnimationDrawable)mainLayout.getBackground();
        animation.setEnterFadeDuration(2000);
        animation.setExitFadeDuration(2000);
        animation.start();
    }

    public boolean checkErrors() {
        // This function checks the errors in the username and password fields
        // It returns true if there are errors and false otherwise
        boolean retVal = false;
        if (username.getText().toString().length() == 0) {
            username.setError("Username can't be Empty");
            retVal = true;
        } else if (username.getText().toString().length() > 12 || username.getText().toString().length() < 6) {
            username.setError("Username must have 6 - 12 characters");
            retVal = true;
        } else if (username.getText().toString().contains(" ")) {
            username.setError("Username can't contain spaces");
            retVal = true;
        }
        if (enterName.getText().toString().length() == 0) {
            enterName.setError("Name can't be Empty");
            retVal = true;
        } else if (enterName.getText().toString().length() > 24 || enterName.getText().toString().length() < 8) {
            enterName.setError("Name must have 8 - 24 characters");
            retVal = true;
        }
        if (password.getText().toString().length() == 0) {
            password.setError("Password can't be Empty");
            retVal = true;
        } else if (password.getText().toString().length() > 12 || password.getText().toString().length() < 6) {
            password.setError("Password must have 6 - 12 characters");
            retVal = true;
        }
        if (!confirm_password.getText().toString().equals(password.getText().toString())) {
            confirm_password.setError("Passwords do not match !");
            retVal = true;
        }
        return retVal;
    }

    public void goToLogin() {
        Intent loginIntent = new Intent(this, Login.class);
        loginIntent.putExtra("username", username.getText().toString());
        loginIntent.putExtra("password", password.getText().toString());
        Register.this.startActivity(loginIntent);
    }

    public void showToast(String message) {
        Toast.makeText(this, message,Toast.LENGTH_LONG).show();
    }

}
