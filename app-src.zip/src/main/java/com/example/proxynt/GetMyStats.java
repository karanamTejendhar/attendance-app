package com.example.proxynt;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static android.content.Context.MODE_PRIVATE;


public class GetMyStats extends Fragment {

    private OnFragmentInteractionListener mListener;
    private SharedPreferences sp;
    private SharedPreferences.Editor ed;
    private View main_view;
    private Spinner student_course_spinner;
    private Button GetStats;
    private ListView list;
    private NetworkManager networkManager;
    private StudentListAdapter adapter;
    private ArrayAdapter<String> spinner_adapter;
    private TextView s_percentage;
    private TextView s_proxies;

    public GetMyStats() {
        // Required empty public constructor
    }


    public static GetMyStats newInstance(String param1, String param2) {
        GetMyStats fragment = new GetMyStats();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            return ;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        main_view = inflater.inflate(R.layout.fragment_get_my_stats, container, false);
        // Call init() only after assigining the main_view
        init();

        GetStats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the Selected course and get attendance list from server
                // Dummy Code
                // Always scroll the list view to top to avoid artifacts
                list.setSelection(0);
                try {
                    String roll = sp.getString("username", null);
                    String course = student_course_spinner.getSelectedItem().toString();
                    String stats = networkManager.getMyStats(roll, course);
                    if (stats == null) {
                        showToast("Failed to Get Stats ! Try Again !!");
                        return ;
                    }
                    if (stats.equals("n")) {
                        StudentListItem[] items = new StudentListItem[] {
                            new StudentListItem("Zero Attendance", "0"),
                        };
                        s_proxies.setText("None");
                        s_percentage.setText("0%");
                        adapter = new StudentListAdapter(getActivity(), R.layout.student_list_row, items);
                        list.setAdapter(adapter);
                        list.setSelection(0);
                        return ;
                    }
                    // parse the stats string and create student items list
                    String []splitted = stats.split("\\$");
                    // each element of the array is <date>:<status>
                    String date, status;
                    ArrayList<StudentListItem> temp_list = new ArrayList<>();
                    int c_count = 0;
                    int p_count = 0;
                    int pr_count = 0;
                    for (String combo:splitted) {
                        c_count++;
                        date = combo.split("\\:")[0];
                        status = combo.split("\\:")[1];
                        if (status.equals("p")) {
                            p_count++;
                        } else if (status.equals("pr")) {
                            pr_count++;
                        }
                        temp_list.add(new StudentListItem(date, status.toUpperCase()));
                    }
                    s_percentage.setText("Attendance : " + String.valueOf(100 * p_count/c_count) + "%(" + p_count + "/" + c_count+ ")");
                    s_proxies.setText("Proxies : " + String.valueOf(pr_count));
                    StudentListItem[] items = temp_list.toArray(new StudentListItem[temp_list.size()]);
                    adapter = new StudentListAdapter(getActivity(), R.layout.student_list_row, items);
                    list.setAdapter(adapter);
                    list.setSelection(0);
                    return ;
                } catch (Exception ex) {
                    showToast("Failed to Get Stats ! Try Again !!");
                    ex.printStackTrace();
                    return ;
                }
            }
        });

        return main_view;
    }

    public void init() {
        sp = getActivity().getSharedPreferences("LOGIN", MODE_PRIVATE);
        ed = sp.edit();
        String[] course_list = sp.getString("courses", null).split("\\$", 20);
        GetStats = main_view.findViewById(R.id.get_student_stats);
        list = main_view.findViewById(R.id.student_listview);
        student_course_spinner = main_view.findViewById(R.id.stat_student_course_spinner);
        spinner_adapter = new ArrayAdapter<>(getActivity(), R.layout.spinner_layout, course_list);
        spinner_adapter.setDropDownViewResource(R.layout.spinner_layout);
        student_course_spinner.setAdapter(spinner_adapter);
        networkManager = new NetworkManager(getString(R.string.ipaddress), 6969);
        s_proxies = main_view.findViewById(R.id.s_proxies);
        s_percentage = main_view.findViewById(R.id.s_percent);
    }

    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }


    public void showToast(String message) {
        Toast.makeText(getActivity(), message,Toast.LENGTH_LONG).show();
    }
}
