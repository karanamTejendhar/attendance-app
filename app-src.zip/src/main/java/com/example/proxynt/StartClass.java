package com.example.proxynt;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.text.format.Formatter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

import static android.content.Context.LOCATION_SERVICE;
import static android.content.Context.MODE_PRIVATE;


public class StartClass extends Fragment implements AdapterView.OnItemSelectedListener {

    // Items in the View
    Spinner course_spinner;
    View view;
    Button start_class_button;
    Button possible_proxies;
    String selected_item;
    TextView code;
    String classStatus;
    Chronometer timer;
    NetworkManager networkManager;
    String username;
    String course_id;
    String imei;
    String current_selected_course = null;
    private final int MY_PHONE_PERMISSION = 1;
    TelephonyManager telephonyManager;
    private OnFragmentInteractionListener mListener;
    private WifiManager wifiManager;
    private String ipaddress;

    public StartClass() {
        // Required empty public constructor
    }
    public static StartClass newInstance(String param1, String param2) {
        StartClass fragment = new StartClass();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    // User Methods
    public void init() {
        SharedPreferences sp = getActivity().getSharedPreferences("LOGIN", MODE_PRIVATE);
        username = sp.getString("username", null);

        networkManager = new NetworkManager(getString(R.string.ipaddress), 6969);
        code = this.view.findViewById(R.id.unique_code);
        classStatus = "not yet";
        timer = this.view.findViewById(R.id.attendance_timer);

        code.setHint("Unique Code");
        start_class_button = this.view.findViewById(R.id.start_class_button);
        possible_proxies = this.view.findViewById(R.id.proxy_button);
        // The proxy button is initially unclickable
        possible_proxies.setEnabled(false);
        // Start class is activated only after the teacher selects a course
        // possible proxies is activated only after the teacher ends the attendance
        course_spinner = this.view.findViewById(R.id.teacher_course_spinner);
        String[] courses = sp.getString("courses", null).split("\\$", 20);
        selected_item = courses[0];
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), R.layout.spinner_layout, courses);
        adapter.setDropDownViewResource(R.layout.spinner_layout);
        course_spinner.setAdapter(adapter);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View main_view = inflater.inflate(R.layout.fragment_start_class, container, false);
        this.view = main_view;
        // After Opening this fragment we must get the course list of the current Professor
        // GetCourseList() returns an array of courses offered by the professor
        // Call init after setting the view
        init();

        try {

            telephonyManager = (TelephonyManager) getActivity().getSystemService(Context.TELEPHONY_SERVICE);
            imei = telephonyManager.getDeviceId();

        } catch (SecurityException se) {
            if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
                // Location Permission is not granted
                // Explicitly ask for user permission
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_PHONE_STATE}, MY_PHONE_PERMISSION);
            }
        }

        start_class_button.setEnabled(true);
        // Add Button Listeners
        start_class_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(classStatus.equals("not yet")) {
                    // class is not yet started
                    try {
                        wifiManager = (WifiManager)getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                        WifiInfo wifiInf = wifiManager.getConnectionInfo();
                        int i_addr = wifiInf.getIpAddress();
                        String f_ipaddress= String.format("%d.%d.%d.%d", (i_addr & 0xff),(i_addr >> 8 & 0xff),(i_addr >> 16 & 0xff),(i_addr >> 24 & 0xff));
                        ipaddress = f_ipaddress.split("\\.")[0] + f_ipaddress.split("\\.")[1];
                        System.out.println("IP : " + ipaddress);
                        // Generate Unique Code of 6 chars
                        String unique_code = generateCode(6);
                        code.setText(unique_code);
                        course_id = course_spinner.getSelectedItem().toString();
                        current_selected_course = course_id;
                        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_PHONE_STATE)!= PackageManager.PERMISSION_GRANTED) {
                            // Location Permission is not granted
                            // Explicitly ask for user permission
                            ActivityCompat.requestPermissions(getActivity(),new String[]{Manifest.permission.READ_PHONE_STATE},MY_PHONE_PERMISSION);

                        }
                        String start_stop_status = networkManager.ClassStartStop(course_id, username, unique_code, ipaddress);
                        if (start_stop_status.equals("success")) {
                            showToast(course_id + " Started");
                        } else if(start_stop_status.equals("fail")) {
                            showToast("Error Starting Class");
                            return ;
                        } else if (start_stop_status.equals("n_error")) {
                            showToast("Network Error ! Please connect to Institute Wifi !");
                            return ;
                        }
                        // Set the button name to Stop Class
                        start_class_button.setText("Stop Class");
                        classStatus = "started";
                        timer.setBase(SystemClock.elapsedRealtime());
                        timer.start();
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        showToast("Network Error Please Try Again !!!");

                    }
                } else if(classStatus.equals("started")) {
                       // class is started already
                    try {
                        String start_stop_status = networkManager.ClassStartStop(course_id, username, "n","n");
                        // To Stop class we send null as IMEI, (0, 0) as location
                        if (start_stop_status.equals("success")) {
                            showToast(course_id + " Stopped");
                        } else if (start_stop_status.equals("fail")) {
                            showToast("Error Stopping Class !!!");
                            return;
                        } else if (start_stop_status.equals("n_error")) {
                            showToast("Network Error ! Please connect to Institute Wifi !");
                            return;
                        }
                    } catch (Exception ex) {
                        System.out.println("Exception Occured while starting class !!!");
                        ex.printStackTrace();
                    }
                    start_class_button.setText("Attendance Complete");
                    start_class_button.setEnabled(false);
                    possible_proxies.setEnabled(true);
                    classStatus = "ended";
                    timer.stop();
                } else{
                    // class is over
                    return ;
                }
            }
        });

        possible_proxies.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                if (classStatus.equals("ended")) {
                    // take user to Proxy Page
                    Intent proxy_intent = new Intent(getActivity(), proxies.class);
                    proxy_intent.putExtra("courseID", current_selected_course);
                    startActivity(proxy_intent);
                } else {
                    return ;
                }
            }
        });

        return view;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String item = parent.getItemAtPosition(position).toString();
        this.selected_item = item;
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }

    private String generateCode(int size) {
        String CHARS = "abcdefghijklmnopqrstuvwxyz0123456789";
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i< size; i++) {
            sb.append(CHARS.charAt(random.nextInt(CHARS.length())));
        }
        return sb.toString();
    }

    public void showToast(String message) {
        Toast.makeText(getActivity(), message,Toast.LENGTH_LONG).show();
    }

}

