package com.example.proxynt;

public class TeacherListItem {
    public String name;
    public String roll_number;

    public TeacherListItem(String name, String roll) {
        this.name = name;
        this.roll_number = roll;
    }
}
